from django.apps import AppConfig


class FtpConfig(AppConfig):
    name = 'ftp'
